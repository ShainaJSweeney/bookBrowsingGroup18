/*
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {

  constructor() { }
}
*/

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpClientModule } from '@angular/common/http'


export interface Book { 
  name: string
}

export interface Author {
  name: string
}

export interface Review {
  name: string
}

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {
  constructor(private http: HttpClient) { }
  
  newname: string;
  
  /*
  getAllBooks(): Observable<Book[]> {
    return this.http.get<Book[]>('http://localhost:8000/10')
  }
  */

  getBook(name: string): Observable<Book> {
    return this.http.get<Book>('http://localhost:8000/book/' + name)   //this will get the properties of a book.
  }

  getAuthor(name: string): Observable<Book> {
    return this.http.get<Book>('http://localhost:8000/author/' + name)   //this will get the author name from the author collection.
  }

  getReview(name: string): Observable<Book> {
    return this.http.get<Book>('http://localhost:8000/review/' + name)   //this will get the reviews name from the review collection.
  }
  
  insertBook(book: Book): Observable<Book> {
    return this.http.post<Book>('http://localhost:8000/api/books/', book)
  }
  
  updateBook(book: Book): Observable<void> {
    return this.http.put<void>(
      'http://localhost:8000/api/books/' + book.name,
      book
    )
  }
  
  deleteBook(name: string) {
    return this.http.delete('http://localhost:8000/api/books/' + name)
  }
  
  setId(name: string){
     this.newname = name;
  }

  getId(){
     return this.newname;
  }

  searchBook(name: string): Observable<Book> {
    return this.http.get<Book>('http://localhost:8000/search/' + name)
  }


  firstClick(){
  console.log('I was clicked');
  }

}