export interface Book {
    _id: number;
    name: string;
  }
