import { Book } from './book';

export const BOOKS: Book[] = [
  { id: 11, name: 'The Little Prince' },
  { id: 12, name: 'The Help' },
  { id: 13, name: 'The Kite Runner' },
  { id: 14, name: 'Gone Girl' },
  { id: 15, name: 'Blind Spots' },
  { id: 16, name: 'Where The Crawdads Sing' },
  { id: 17, name: 'Diary Of A Wimpy Kid' },
  { id: 18, name: 'The Lord Of The Rings' },
  { id: 19, name: 'The Hobbit' }
];