/*
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {

  constructor() { }
}
*/

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpClientModule } from '@angular/common/http'

export interface Book { 
  name: string
}

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {
  constructor(private http: HttpClient) { }

  getAllBooks(): Observable<Book[]> {
    return this.http.get<Book[]>('http://localhost:8000/10')
  }
  
  getBook(name: string): Observable<Book> {
    return this.http.get<Book>('http://localhost:8000/api/books/' + name)
  }
  
  insertBook(book: Book): Observable<Book> {
    return this.http.post<Book>('http://localhost:8000/api/books/', book)
  }
  
  updateBook(book: Book): Observable<void> {
    return this.http.put<void>(
      'http://localhost:8000/api/books/' + book.name,
      book
    )
  }
  
  deleteBook(name: string) {
    return this.http.delete('http://localhost:8000/api/books/' + name)
  }
  
  firstClick(){
  console.log('I was clicked');
  }

}