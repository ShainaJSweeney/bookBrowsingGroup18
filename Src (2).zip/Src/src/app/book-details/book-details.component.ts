import { Component, OnInit } from '@angular/core';
import { BookserviceService } from '../bookservice.service';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {
  h1Style : boolean = true; 
  h2Style: boolean = true;
  h3Style: boolean = true;
  h4Style: boolean = true;
  h5Style: boolean = true; 
  h6Style: boolean = true;
  h7Style: boolean = true;
  //backgroundStyle: boolean = true;
  Books: Object;

  constructor(private book: BookserviceService, private router: Router) { }

  cusRevButton(){
    this.router.navigateByUrl('/books');
  }

  ngOnInit(): void {
     this.book.getAllBooks().subscribe(book => {
     this.Books = book;
     console.log(this.Books);
  })

  }
    firstClick(){
      this.book.firstClick();
    }

    
}
